namespace Shell
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
        }

        private void SortButton_Click(object sender, EventArgs e)
        {
            // Read input values from the textbox
            string inputString = InputNumbers.Text;
            string[] inputValues = inputString.Split(' ');

            // Convert input values to integers
            int[] numbers = new int[inputValues.Length];
            for (int i = 0; i < inputValues.Length; i++)
            {
                if (!int.TryParse(inputValues[i], out numbers[i]))
                {
                    MessageBox.Show("Invalid input value: " + inputValues[i]);
                    return;
                }
            }

            // Sort the array using Shell sort algorithm
            ShellSort(numbers);

            // Display the sorted values in the output textbox
            ResultLabel.Text = string.Join(" ", numbers);
        }

        private void ShellSort(int[] array)
        {
            int n = array.Length;
            int gap = n / 2;

            while (gap > 0)
            {
                for (int i = gap; i < n; i++)
                {
                    int temp = array[i];
                    int j = i;

                    while (j >= gap && array[j - gap] > temp)
                    {
                        array[j] = array[j - gap];
                        j -= gap;
                    }

                    array[j] = temp;
                }

                gap /= 2;
            }
        }

        private void HelpButton_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "Spravka.chm");
        }
    }
}