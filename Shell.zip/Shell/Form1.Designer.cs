﻿namespace Shell
{
    partial class Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SortButton = new Button();
            ResultLabel = new Label();
            InputNumbers = new TextBox();
            TextExercice = new Label();
            HelpButton = new Button();
            SuspendLayout();
            // 
            // SortButton
            // 
            SortButton.BackColor = SystemColors.HotTrack;
            SortButton.FlatStyle = FlatStyle.Flat;
            SortButton.ForeColor = SystemColors.ControlLightLight;
            SortButton.Location = new Point(185, 134);
            SortButton.Name = "SortButton";
            SortButton.Size = new Size(109, 35);
            SortButton.TabIndex = 0;
            SortButton.Text = "Сортировать";
            SortButton.UseVisualStyleBackColor = false;
            SortButton.Click += SortButton_Click;
            // 
            // ResultLabel
            // 
            ResultLabel.AutoSize = true;
            ResultLabel.Location = new Point(141, 201);
            ResultLabel.Name = "ResultLabel";
            ResultLabel.Size = new Size(60, 15);
            ResultLabel.TabIndex = 1;
            ResultLabel.Text = "Результат";
            // 
            // InputNumbers
            // 
            InputNumbers.Location = new Point(141, 105);
            InputNumbers.Name = "InputNumbers";
            InputNumbers.Size = new Size(199, 23);
            InputNumbers.TabIndex = 2;
            // 
            // TextExercice
            // 
            TextExercice.AutoSize = true;
            TextExercice.Location = new Point(141, 87);
            TextExercice.Name = "TextExercice";
            TextExercice.Size = new Size(182, 15);
            TextExercice.TabIndex = 3;
            TextExercice.Text = "Введите значения через пробел";
            // 
            // HelpButton
            // 
            HelpButton.BackColor = SystemColors.Info;
            HelpButton.FlatStyle = FlatStyle.Flat;
            HelpButton.ForeColor = Color.SandyBrown;
            HelpButton.Location = new Point(12, 12);
            HelpButton.Name = "HelpButton";
            HelpButton.RightToLeft = RightToLeft.No;
            HelpButton.Size = new Size(75, 23);
            HelpButton.TabIndex = 4;
            HelpButton.Text = "Справка";
            HelpButton.UseVisualStyleBackColor = false;
            HelpButton.Click += HelpButton_Click;
            // 
            // Form
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(476, 301);
            Controls.Add(HelpButton);
            Controls.Add(TextExercice);
            Controls.Add(InputNumbers);
            Controls.Add(ResultLabel);
            Controls.Add(SortButton);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Сортировка с помощью алгоритма Шелла";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button SortButton;
        private Label ResultLabel;
        private TextBox InputNumbers;
        private Label TextExercice;
        private Button HelpButton;
    }
}